package modelo;

public class Grupo {
	
	private String nombre;
	private int votosPositivos;
	private int votosNegativos;
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getVotosPositivos() {
		return votosPositivos;
	}
	public void setVotosPositivos(int votosPositivos) {
		this.votosPositivos = votosPositivos;
	}
	public int getVotosNegativos() {
		return votosNegativos;
	}
	public void setVotosNegativos(int votosNegativos) {
		this.votosNegativos = votosNegativos;
	}

}
